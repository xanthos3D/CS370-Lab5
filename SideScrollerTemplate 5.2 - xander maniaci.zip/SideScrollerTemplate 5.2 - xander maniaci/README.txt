launch the file "SideScrollerTemplate.uproject" and click the play button to run in the editor.
make sure to add the starter conent to the content folder. everything should be working as intended.
